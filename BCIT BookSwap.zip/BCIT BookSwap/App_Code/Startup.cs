﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(BCITBookSwap.Startup))]
namespace BCITBookSwap
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
