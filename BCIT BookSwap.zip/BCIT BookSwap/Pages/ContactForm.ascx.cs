﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Mail;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Pages_ContactForm : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void SendButton_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            string fileName = Server.MapPath("~/App_Data/ContactForm.txt");
            string mailBody = File.ReadAllText(fileName);
            mailBody = mailBody.Replace("##Name##", Name.Text);
            mailBody = mailBody.Replace("##Email##", Email.Text);
            mailBody = mailBody.Replace("##Telephone##", Telephone.Text);
            mailBody = mailBody.Replace("##Comments##", Comments.Text);
            MailMessage myMessage = new MailMessage();
            myMessage.Subject = "Response from BCIT BookSwap";
            myMessage.Body = mailBody;
            myMessage.From = new MailAddress("BCITBOOKSWAP@gmail.com", "BCIT BookSwap");
            myMessage.To.Add(new MailAddress("BSYS4000@gmail.com", "BCIT BookSwap"));
            myMessage.ReplyToList.Add(new MailAddress(Email.Text));
            SmtpClient mySmtpClient = new SmtpClient();
            mySmtpClient.Send(myMessage);
            Message.Visible = true;
            FormTable.Visible = false;
        }
    }
}
