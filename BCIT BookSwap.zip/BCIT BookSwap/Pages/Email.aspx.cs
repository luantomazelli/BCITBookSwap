﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Pages_Email : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        MailMessage myMessage = new MailMessage();
        myMessage.Subject = "Test Message";
        myMessage.Body = "Hello world, from BCIT BookSwap";
        myMessage.From = new MailAddress("BCITBOOKSWAP@gmail.com", "BCIT BookSwap");
        myMessage.To.Add(new MailAddress("BSYS4000@gmail.com", "BCIT BookSwap"));
        SmtpClient mySmtpClient = new SmtpClient();
        mySmtpClient.Send(myMessage);
    }
}