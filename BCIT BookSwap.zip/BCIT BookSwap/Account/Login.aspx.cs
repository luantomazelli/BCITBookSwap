﻿using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;
using System;
using System.Web;
using System.Web.UI;
using BCITBookSwap;

public partial class Account_Login : Page
{
        protected void Page_Load(object sender, EventArgs e)
        {

        }
}