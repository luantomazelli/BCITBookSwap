﻿using Microsoft.AspNet.Identity;
using System;
using System.Linq;
using System.Web.UI;
using BCITBookSwap;


public partial class Account_Register : Page
{
   
    protected void CreateUser_Click(object sender, EventArgs e)
    {

    }

    protected void ContactNumber_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void DetailsView1_PageIndexChanging(object sender, System.Web.UI.WebControls.DetailsViewPageEventArgs e)
    {

    }
    protected void CreateUserWizard1_ContinueButtonClick(object sender, EventArgs e)
    {
        Response.Redirect("~/Default.aspx");
    }

}